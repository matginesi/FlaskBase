# WebApp Base

Flask/PostgreSQL starter base for PoCs and small MVPs.

It is designed to give you:

- a ready-made UI shell
- authentication and admin flows
- runtime settings stored in the database
- built-in and ZIP-installable add-ons
- logging, audit, jobs, and platform primitives out of the box
- an admin database page for diagnostics and maintenance
- communications with inbox messages and email templates

## What This Project Is For

The goal is simple: when you build a new service, you should be able to add it as an add-on and immediately reuse:

- the app shell
- the user/admin structure
- the database bootstrap
- platform config and secrets
- logging and operational pages

## Current Baseline

- PostgreSQL only
- seed data loaded from JSON
- runtime settings persisted in a richer `app_settings` row
- runtime settings saved and applied from a single DB-backed flow
- secure FastAPI surface for third-party integrations
- desktop sidebar from `md` and up
- mobile top navigation below `md`
- UI localization support for English and Italian
- add-ons with user/admin views
- standalone `ui_template/` matching the real app UI
- async-capable job runtime initialized by the app factory
- email delivery moved off the request path when the job runtime is available

## Seed Credentials

- `admin@test.com` / `admin`
- `user@test.com` / `user`

## Quick Start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

bash init_postgres.sh
python cli.py init-db-complete --force
python cli.py serve --host 127.0.0.1 --port 5000
python cli.py serve-api --host 127.0.0.1 --port 8000
```

For a more robust multi-user runtime, prefer:

```bash
python cli.py serve-stack --host 127.0.0.1 --port 5000 --web-workers 2 --threads 4 --job-workers 1
```

That starts:

- Gunicorn web workers for concurrent requests
- a dedicated job worker process for async background jobs

Security note:

- set `RATELIMIT_STORAGE_URI=redis://localhost:6379/0` (or another shared backend) when using multiple workers
- in production, in-memory rate limiting is rejected because it can be bypassed across workers
- if the app is behind a reverse proxy, configure `PROXY_FIX_X_FOR` and related `PROXY_FIX_*` values so `request.remote_addr` is trustworthy

## Configuration Model

The project uses three separate layers:

1. `.env`
   Secrets, DB URLs, deployment flags.
2. `app_config.json`
   Seed-only defaults used to create the first runtime settings row, including initial pages/features.
3. `app_settings`
   The real runtime source of truth for app name/version/base URL, core settings, add-ons, pages, theme, visual settings, revision, and import/export metadata.

Seed data lives in [seed/seed.json](/home/matteo/PycharmProjects/webApp/seed/seed.json).

Runtime settings can be exported and imported as JSON via:

```bash
python cli.py settings-export ./settings_export.json
python cli.py settings-import ./settings_export.json
```

The admin settings page also supports:

- full runtime editing for application, security, auth, email, logging, dashboard, theme, visual, and add-ons
- FastAPI runtime editing for API public URL, docs/OpenAPI paths, and browser CORS allow-list
- JSON export
- JSON import
- DB log persistence controls with burst throttling and audit noise reduction
- reliable checkbox/toggle persistence even when fields are unchecked
- immediate runtime apply for app identity, theme, visual, logging, and add-on policies

### Host allow-list (LAN dev vs production)

The app enforces an allow-list on the HTTP `Host` header to prevent host-header attacks.

- **Development (default):** allow all hosts (so you can open the app from another device on your LAN).
  - Control via `.env`: `DEV_ALLOW_ALL_HOSTS=true|false`.
- **Production:** `*` is never allowed.
  - If `SECURITY.ALLOWED_HOSTS` is not configured in runtime settings, the app derives the allow-list from `SETTINGS.BASE_URL`.
  - You can extend it via `.env` with `EXTRA_ALLOWED_HOSTS=api.example.com,admin.example.com`.

Supported patterns inside `SECURITY.ALLOWED_HOSTS`:

- exact hostnames/IPs (e.g. `example.com`, `192.168.1.10`)
- wildcard subdomains (e.g. `*.example.com`)
- CIDR subnets (e.g. `192.168.1.0/24`)

### Localization

The UI now supports:

- English (`en`) as the default runtime language
- Italian (`it`) as an alternate UI language

Language resolution order:

1. `?lang=en|it` in the current request
2. session preference
3. authenticated user locale
4. browser `Accept-Language`

The main shell exposes a language switcher in the topbar.

### Runtime Settings Reliability

Runtime settings are designed to be deterministic:

- settings are written to PostgreSQL first
- the saved row is reloaded after commit
- runtime config is reapplied from the saved row, not from a stale in-memory payload
- add-on reload is attempted only after the config layer is already coherent

Practical consequence:

- if a value is visible in `/admin/settings` after save and refresh, that value is the runtime value
- toggles that are turned off remain off after refresh
- app name/version changes propagate to the shell from the DB-backed runtime state

### Add-on Install and Restart

Installing a ZIP add-on is a two-step activation process:

1. the package is validated and copied into the configured add-on root
2. runtime settings are updated to enable the new add-on, then the server is restarted so new Flask routes can be registered during bootstrap

Important:

- a newly installed add-on with new Flask routes is not considered fully active until restart completes
- the install modal in `/admin/settings` applies settings and then requests a real restart
- built-in add-ons are part of the bundle; ZIP add-ons live in the add-on root and can be exported or removed from the admin UI
- installing an add-on is equivalent to executing arbitrary Python code on the server; only trusted packages should be installed
- installed add-ons persist a SHA-256 checksum and are refused at load time if files change on disk

## API Platform

The external API surface is served by FastAPI and is intentionally separated from the Flask web UI.

Main characteristics:

- versioned routes under `/v1/*`
- bearer-token authentication against the same `api_tokens` table
- host-header validation using the runtime allow-list
- request size enforcement aligned with the runtime security settings
- OpenAPI/Swagger/ReDoc exposure controlled by runtime config
- add-ons can publish secure API routers through their manifest

Production recommendation:

- keep `DOCS_ENABLED=false` and `OPENAPI_ENABLED=false` unless you explicitly need public schema/docs exposure

Crypto note:

- Fernet-encrypted MFA secrets, add-on secrets, and token reveal records are derived from `SECRET_KEY`
- changing `SECRET_KEY` invalidates existing encrypted data unless you re-encrypt it with a migration utility

Default entrypoints:

- `/v1/health`
- `/v1/meta`
- `/v1/meta/routes`
- `/v1/auth/me`
- `/v1/auth/token`

Start it with:

```bash
python cli.py serve-api --host 127.0.0.1 --port 8000
```

The default runtime seed exposes the API as:

- `http://127.0.0.1:8000`

## Database Admin Page

The admin database page is PostgreSQL-oriented and exposes:

- database overview and connection stats
- table size and row estimates
- runtime settings metadata from `app_settings`
- read-only SQL console for single `SELECT` queries
- log retention cleanup
- `ANALYZE`
- `VACUUM (ANALYZE)`
- JSON database snapshot export

## Important Paths

- [app](/home/matteo/PycharmProjects/webApp/app)
- [addons](/home/matteo/PycharmProjects/webApp/addons)
- [ui_template](/home/matteo/PycharmProjects/webApp/ui_template)
- [tests/test_all.py](/home/matteo/PycharmProjects/webApp/tests/test_all.py)
- [init_postgres.sh](/home/matteo/PycharmProjects/webApp/init_postgres.sh)

## Tests

Regular test run:

```bash
pytest -q
```

Full-stack stress run:

```bash
python tests/test_all.py
```

Requirements for `tests/test_all.py`:

- reachable PostgreSQL via `DATABASE_URL` or `TEST_DATABASE_URL`
- Playwright browser installed
- working seed/bootstrap flow
- a restart-capable runtime when testing ZIP add-on install flows

## Documentation

- [UI](docs/UI.md)
- [Add-ons](docs/ADDONS.md)
- [Add-on Functions](docs/ADDON_FUNCTIONS.md)
- [Create an Add-on](docs/ADDON_TUTORIAL.md)
- [Codebase](docs/CODEBASE.md)
- [Security](docs/SECURITY.md)
