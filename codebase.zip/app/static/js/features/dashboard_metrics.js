(function(){
  'use strict';

  function $(id){ return document.getElementById(id); }

  function clamp(n, a, b){
    n = Number(n);
    if(!Number.isFinite(n)) return a;
    return Math.max(a, Math.min(b, n));
  }

  function cssVar(name, fallback){
    try{
      const v = getComputedStyle(document.documentElement).getPropertyValue(name);
      return (v && String(v).trim()) ? String(v).trim() : fallback;
    }catch(e){
      return fallback;
    }
  }

  function ensureCanvasSize(canvas){
    if(!canvas) return null;
    const dpr = window.devicePixelRatio || 1;
    const cw = Math.max(1, Math.floor(canvas.clientWidth));
    const chAttr = Number(canvas.getAttribute('height') || 180);
    const cssHeight = Math.max(120, Math.floor(canvas.clientHeight || chAttr || 180));
    const ch = cssHeight;
    const wantW = Math.floor(cw * dpr);
    const wantH = Math.floor(ch * dpr);

    canvas.style.height = cssHeight + 'px';

    // Avoid flicker: only resize when needed
    if(canvas.width !== wantW || canvas.height !== wantH){
      canvas.width = wantW;
      canvas.height = wantH;
    }
    return {w: wantW, h: wantH, dpr};
  }

  function drawGrid(ctx, w, h, pad, opts){
    const grid = (opts && opts.grid) ? opts.grid : {x:5, y:4};
    const gx = Math.max(2, Number(grid.x || 5));
    const gy = Math.max(2, Number(grid.y || 4));

    ctx.save();
    ctx.globalAlpha = 0.12;
    ctx.lineWidth = 1;

    // verticals
    for(let i=0;i<=gx;i++){
      const x = pad + (w - pad*2) * (i/gx);
      ctx.beginPath();
      ctx.moveTo(x, pad);
      ctx.lineTo(x, h - pad);
      ctx.stroke();
    }
    // horizontals
    for(let j=0;j<=gy;j++){
      const y = pad + (h - pad*2) * (j/gy);
      ctx.beginPath();
      ctx.moveTo(pad, y);
      ctx.lineTo(w - pad, y);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawLineChart(canvas, values, opts){
    if(!canvas) return;
    const ctx = canvas.getContext('2d');
    if(!ctx) return;

    const size = ensureCanvasSize(canvas);
    if(!size) return;

    const w = size.w;
    const h = size.h;
    const dpr = size.dpr;

    const pad = 10 * dpr;
    const maxV = (opts && Number.isFinite(opts.max)) ? Number(opts.max) : Math.max(1, ...values);
    const minV = (opts && Number.isFinite(opts.min)) ? Number(opts.min) : 0;

    ctx.clearRect(0,0,w,h);

    // grid + baseline
    ctx.strokeStyle = cssVar('--card-border', 'rgba(148,163,184,.5)');
    drawGrid(ctx, w, h, pad, opts);

    // baseline
    ctx.save();
    ctx.globalAlpha = 0.25;
    ctx.beginPath();
    ctx.moveTo(pad, h - pad);
    ctx.lineTo(w - pad, h - pad);
    ctx.stroke();
    ctx.restore();

    if(!values || values.length < 2) return;

    const n = values.length;
    const dx = (w - pad*2) / (n - 1);

    // line
    ctx.strokeStyle = (opts && opts.color) ? opts.color : cssVar('--accent', '#2563eb');
    ctx.lineWidth = 2 * dpr;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';

    ctx.beginPath();
    for(let i=0;i<n;i++){
      const v = clamp(values[i], minV, maxV);
      const t = (v - minV) / (maxV - minV || 1);
      const x = pad + dx * i;
      const y = (h - pad) - t * (h - pad*2);
      if(i===0) ctx.moveTo(x,y);
      else ctx.lineTo(x,y);
    }
    ctx.stroke();

    // subtle fill
    ctx.save();
    ctx.globalAlpha = 0.08;
    ctx.fillStyle = ctx.strokeStyle;
    ctx.lineTo(w - pad, h - pad);
    ctx.lineTo(pad, h - pad);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  function setBar(barEl, val){
    if(!barEl) return;
    const pct = clamp(val, 0, 100);
    barEl.style.width = pct.toFixed(1) + '%';
    barEl.setAttribute('aria-valuenow', pct.toFixed(1));
  }

  function setText(id, value){
    const el = $(id);
    if(el) el.textContent = value;
  }

  function renderResource(prefix, pct, used, total, unit){
    const safePct = clamp(pct, 0, 100);
    setBar($(prefix + 'PctBar'), safePct);
    setText(prefix + 'PctVal', safePct.toFixed(1) + '%');
    const usedTxt = Number.isFinite(used) ? used.toFixed(unit === 'GB' ? 1 : 0) + ' ' + unit : '—';
    const totalTxt = Number.isFinite(total) ? total.toFixed(unit === 'GB' ? 1 : 0) + ' ' + unit : '—';
    setText(prefix + 'UsedVal', usedTxt);
    setText(prefix + 'TotalVal', totalTxt);
    setText(prefix + 'UsageCopy', (Number.isFinite(used) && Number.isFinite(total)) ? (usedTxt + ' / ' + totalTxt) : '—');
  }

  const root = $('sysMetrics');
  if(!root) return;

  const refreshSec = clamp(root.getAttribute('data-refresh-sec') || 8, 3, 10);

  // history buffers (~60s)
  const maxPoints = Math.max(12, Math.floor(60 / refreshSec));
  const cpuHist = [];
  const loadHist = [];

  function pushHist(arr, v){
    arr.push(Number.isFinite(Number(v)) ? Number(v) : 0);
    while(arr.length > maxPoints) arr.shift();
  }

  // init
  pushHist(cpuHist, Number(root.getAttribute('data-initial-cpu') || 0));
  pushHist(loadHist, Number(root.getAttribute('data-initial-load') || 0));
  renderResource('ram', Number(root.getAttribute('data-initial-ram-pct') || 0), Number(root.getAttribute('data-initial-ram-used') || 0), Number(root.getAttribute('data-initial-ram-total') || 0), 'MB');
  renderResource('disk', Number(root.getAttribute('data-initial-disk-pct') || 0), Number(root.getAttribute('data-initial-disk-used') || 0), Number(root.getAttribute('data-initial-disk-total') || 0), 'GB');

  const cpuColor = cssVar('--accent', '#2563eb');
  const loadColor = cssVar('--success', '#16a34a');

  function redraw(){
    drawLineChart($('cpuChart'), cpuHist, {min:0, max:100, color: cpuColor, grid:{x:6,y:4}});
    const mx = Math.max(1, ...loadHist);
    drawLineChart($('loadChart'), loadHist, {min:0, max: mx * 1.25, color: loadColor, grid:{x:6,y:4}});
    if($('cpuChartCurrent')) $('cpuChartCurrent').textContent = (cpuHist[cpuHist.length - 1] ?? 0).toFixed(1) + '%';
    if($('cpuChartPeak')) $('cpuChartPeak').textContent = Math.max(...cpuHist, 0).toFixed(1) + '%';
    if($('loadChartCurrent')) $('loadChartCurrent').textContent = String((loadHist[loadHist.length - 1] ?? 0).toFixed ? (loadHist[loadHist.length - 1] ?? 0).toFixed(2) : (loadHist[loadHist.length - 1] ?? 0));
    if($('loadChartPeak')) $('loadChartPeak').textContent = Math.max(...loadHist, 0).toFixed(2);
  }

  redraw();

  let inflight = false;
  async function tick(){
    if(inflight) return;
    inflight = true;
    try{
      const res = await fetch('/metrics', {headers:{'Accept':'application/json'}});
      if(!res.ok) return;
      const data = await res.json();

      if(typeof data.cpu_pct !== 'undefined'){
        const cpu = Number(data.cpu_pct);
        if(Number.isFinite(cpu)){
          if($('cpuPctVal')) $('cpuPctVal').textContent = cpu.toFixed(1) + '%';
          setBar($('cpuPctBar'), cpu);
          pushHist(cpuHist, cpu);
        }
      }

      if(typeof data.load_1 !== 'undefined'){
        const l1 = data.load_1;
        const l5 = data.load_5;
        const l15 = data.load_15;

        if($('load1Val')) $('load1Val').textContent = (l1 === null || typeof l1 === 'undefined') ? '—' : String(l1);
        if($('load5Val')) $('load5Val').textContent = (l5 === null || typeof l5 === 'undefined') ? '—' : String(l5);
        if($('load15Val')) $('load15Val').textContent = (l15 === null || typeof l15 === 'undefined') ? '—' : String(l15);

        const loadNum = Number(l1);
        if(Number.isFinite(loadNum)){
          pushHist(loadHist, loadNum);
        }
      }

      // RAM: compute pct if server doesn't provide it
      let ramPct = (typeof data.ram_used_pct !== 'undefined') ? Number(data.ram_used_pct) : NaN;
      if(!Number.isFinite(ramPct)){
        const used = Number(data.ram_used_mb);
        const tot = Number(data.ram_total_mb);
        if(Number.isFinite(used) && Number.isFinite(tot) && tot > 0){
          ramPct = (used / tot) * 100.0;
        }
      }
      if(Number.isFinite(ramPct)){
        renderResource('ram', ramPct, Number(data.ram_used_mb), Number(data.ram_total_mb), 'MB');
      }

      // Disk: compute pct if missing
      let diskPct = (typeof data.disk_used_pct !== 'undefined') ? Number(data.disk_used_pct) : NaN;
      if(!Number.isFinite(diskPct)){
        const used = Number(data.disk_used_gb);
        const tot = Number(data.disk_total_gb);
        if(Number.isFinite(used) && Number.isFinite(tot) && tot > 0){
          diskPct = (used / tot) * 100.0;
        }
      }
      if(Number.isFinite(diskPct)){
        renderResource('disk', diskPct, Number(data.disk_used_gb), Number(data.disk_total_gb), 'GB');
      }

      // paint on next frame (no flicker)
      window.requestAnimationFrame(redraw);
    }catch(e){
      // silent: dashboard must remain usable even if metrics fail
    }finally{
      inflight = false;
    }
  }

  // First refresh quickly, then interval
  window.setTimeout(tick, 350);
  window.setInterval(tick, refreshSec * 1000);

  // Optional manual refresh button (if present)
  const btn = $('dashRefreshBtn');
  if(btn){
    btn.addEventListener('click', (e) => { e.preventDefault(); tick(); });
  }

  // Redraw on resize (debounced)
  let resizeT = null;
  const queueRedraw = () => {
    if(resizeT) window.clearTimeout(resizeT);
    resizeT = window.setTimeout(() => window.requestAnimationFrame(redraw), 120);
  };
  window.addEventListener('resize', queueRedraw);

  if(typeof ResizeObserver !== 'undefined'){
    const observer = new ResizeObserver(() => queueRedraw());
    const cpuCanvas = $('cpuChart');
    const loadCanvas = $('loadChart');
    if(cpuCanvas && cpuCanvas.parentElement) observer.observe(cpuCanvas.parentElement);
    if(loadCanvas && loadCanvas.parentElement) observer.observe(loadCanvas.parentElement);
  }
})();
